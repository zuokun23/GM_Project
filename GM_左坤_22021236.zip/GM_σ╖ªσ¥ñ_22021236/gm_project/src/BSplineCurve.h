#pragma once
#include <vector>
#include <Eigen/Dense>
using namespace Eigen;


class BSplineCurve {
public:
    // 从输入的控制顶点得到B样条曲线
    BSplineCurve(std::vector<Vector3f> controlPoints, int k);
    
    BSplineCurve(std::vector<Vector3f> dataPoints, int k, bool interpolation);

    BSplineCurve(std::vector<Vector3f> dataPoints, int k, int h);
    // 返回曲线上t处的点
    Vector3f get(float t);

    // 返回B样条基函数
    float base(int n, int k, float t);

    // 返回第i个控制顶点
    Vector3f getControlPoint(int i);

private:
    // n+1是控制顶点数量，k是阶数
    int n;
    int k;
    std::vector<float> knots;
    std::vector<Vector3f> controlPoints;
    std::vector<float> tt;
};