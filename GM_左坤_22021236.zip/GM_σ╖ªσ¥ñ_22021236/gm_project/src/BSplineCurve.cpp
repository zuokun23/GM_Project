#include "BSplineCurve.h"
#include <Eigen/Dense>

// 从输入的控制顶点得到B样条曲线
BSplineCurve::BSplineCurve(std::vector<Vector3f> controlPoints, int k) {

	this->controlPoints = controlPoints;
    // 给n和k赋值
    this->n = controlPoints.size() - 1;
    this->k = k;
    // 生成长度为n+k+1的节点向量，开头有连续的k个0，结尾有k个1
    knots.resize(n+k+1);
    for(int i = 0 ; i < k ; i++)
        knots[i] = 0;
    for(int i = k ; i < n+1 ; i++)
        knots[i] = knots[i-1] + 1.0/(n-k+2);
    for(int i = n+1 ; i <= n+k ; i++)
        knots[i] = 1;
}

BSplineCurve::BSplineCurve(std::vector<Vector3f> dataPoints, int k, bool interpolation) {
    // 给n和k赋值
    this->n = dataPoints.size() - 1;
    this->k = k;
    // 生成长度为n+k+1的节点向量，开头有连续的k个0，结尾有k个1
    knots.resize(n+k+1);
    for(int i = 0 ; i < k ; i++)
        knots[i] = 0;
    for(int i = k ; i < n+1 ; i++)
        knots[i] = knots[i-1] + 1.0/(n-k+2);
    for(int i = n+1 ; i <= n+k ; i++)
        knots[i] = 1;

    this->tt.resize(n+1);
	tt[0] = 0;
    for(int i = 1 ; i <= n ; i++){
        tt[i] = tt[i-1] + 1.f/n;
    }
	tt[n] -= 0.0001;
    MatrixXf N(n+1,n+1);
    MatrixXf D(n+1,3);
    MatrixXf temp(n+1,3);
    for(int i = 0 ; i<= n ; i++){
        for(int j = 0 ; j < 3 ; j++){
            D(i,j) = dataPoints[i][j];
        }
    }
    for(int i = 0 ; i <= n ; i++){
        for(int j = 0 ; j <= n ; j++){
            N(i,j) = base(j, k, tt[i]);
        }
    }
	
    temp = N.inverse()*D;
	controlPoints.resize(n+1);
    for(int i = 0 ; i<= n ; i++){
        for(int j = 0 ; j < 3 ; j++){
            controlPoints[i][j] = temp(i,j);
        }
    }
}

BSplineCurve::BSplineCurve(std::vector<Vector3f> dataPoints, int k, int h){

    int n = dataPoints.size() - 1;
	this->n = h;
    this->k = k;
    // 生成长度为n+k+1的节点向量，开头有连续的k个0，结尾有k个1
    knots.resize(n+k+1);
    for(int i = 0 ; i < k ; i++)
        knots[i] = 0;
    for(int i = k ; i < n+1 ; i++)
        knots[i] = knots[i-1] + 1.0/(n-k+2);
    for(int i = n+1 ; i <= n+k ; i++)
        knots[i] = 1;

    this->tt.resize(n+1);
	tt[0] = 0;
    for(int i = 1 ; i <= n ; i++){
        tt[i] = tt[i-1] + 1.f/n;
    }
	tt[n] -= 0.0001;

    std::vector<Vector3f> Q(n+1);
    for(int i = 1 ; i < n ; i++){
        Q[i] = dataPoints[i] - base(0, k, tt[i])*dataPoints[0] - base(h, k, tt[i])*dataPoints[n];
    }
    MatrixXf QQ(h-1, 3);
    for(int i = 0 ; i < h-1 ; i++){
        Vector3f tmp(0,0,0);
        for(int j = 1 ; j <= n-1 ; j++){
            tmp += Q[j]*base(i+1, k, tt[j]);
        }
        QQ(i, 0) = tmp[0];
        QQ(i, 1) = tmp[1];
        QQ(i, 2) = tmp[2];
    }

    MatrixXf N(n-1, h-1);
    for(int i = 1 ; i <= n-1 ; i++){
        for(int j = 1 ; j <= h-1 ; j++){
            N(i-1, j-1) = base(j, k, tt[i]);
        }
    }

    MatrixXf temp(h-1, 3);
    temp = (N.transpose()*N).inverse()*QQ;
    controlPoints.resize(h+1);
    controlPoints[0] = dataPoints[0];
    controlPoints[h] = dataPoints[n];
    for(int i = 1 ; i <= h-1 ; i++){
        controlPoints[i][0] = temp(i-1, 0);
        controlPoints[i][1] = temp(i-1, 1);
        controlPoints[i][2] = temp(i-1, 2);
    }

}

// 返回曲线上t处的点
Vector3f BSplineCurve::get(float t) {
    Vector3f point(0,0,0);
    for (int i = 0; i <= n; i ++ ) {
		float tt = base(i, k, t);
        point += tt * controlPoints[i];
    }
    return point;
}

Vector3f BSplineCurve::getControlPoint(int i){
    return controlPoints[i];
}

// 返回B样条基函数
float BSplineCurve::base(int i, int k, float t) {
    // 按照公式递归实现
    if(k == 1){
        
        if(t >= knots[i] && t < knots[i+1])
            return 1.f;
        else
            return 0.f;
        
    }

    float para1, para2;
    if(knots[i+k-1] - knots[i] == 0)
        para1 = 0;
    else
        para1 = (t - knots[i])/(knots[i+k-1] - knots[i]);
    
    if(knots[i+k] - knots[i+1] == 0)
        para2 = 0;
    else
        para2 = (knots[i+k] - t)/(knots[i+k] - knots[i+1]);

    return para1*base(i, k-1, t) + para2*base(i+1, k-1, t);

}