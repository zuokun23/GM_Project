#include "BSplineSurface.h"
#define PI 3.14159f

// 控制顶点写死在构造函数里面
BSplineSurface::BSplineSurface() {
    n = 10;
    controlPoints.resize(n);
    
    for (int i = 0; i < n; i ++ ) {
        for (int j = 0; j < n; j ++ ) {/*
            float x = (float)i/n - 0.5;
            float y = (float)j/n - 0.5;*/
            float alpha = i/((n-1)*1.f)*PI;
            float theta = j/((n-1)*1.f)*PI*2.f;

            float x = sin(alpha)*cos(theta);
            float y = sin(alpha)*sin(theta);
            float z = cos(alpha);
            //controlPoints[i].push_back(Vector3f(x,y,((float)(rand() % 1000) / 1000.f - 0.5f) * 0.2f));
            controlPoints[i].push_back(Vector3f(x,y,z));

        }
    }
}

BSplineSurface::BSplineSurface(bool interpolation) {
    //先从球面上取(n+1)×(n+1)个数据点（矩阵A）
    n = 10;
    controlPoints.resize(n);
    
    for (int i = 0; i < n; i ++ ) {
        for (int j = 0; j < n; j ++ ) {
            float alpha = i/((n-1)*1.f)*PI;
            float theta = j/((n-1)*1.f)*PI*2.f;

            float x = sin(alpha)*cos(theta);
            float y = sin(alpha)*sin(theta);
            float z = cos(alpha);
            //controlPoints[i].push_back(Vector3f(x,y,((float)(rand() % 1000) / 1000.f - 0.5f) * 0.2f));
            controlPoints[i].push_back(Vector3f(x,y,z));

        }
    }
    // 对每行的n+1个数据点进行插值，得到n+1个控制顶点，填入矩阵B中的某一行
	
    std::vector<std::vector<Vector3f>> B(n);
    for (int i = 0; i < n; i ++ ) {
        BSplineCurve curve0(controlPoints[i], 3, true);
        for(int j = 0 ; j < n ; j++){
            B[i].push_back(curve0.getControlPoint(j));
        }
    }
	//int xx = 4;
	//float yy = B[xx, 0) + B(xx, 1) + B(xx, 2) + B(xx, 3) + B(xx, 4);
    // 对矩阵B的每一列的n+1个控制顶点进行插值，得到n+1个控制顶点，填入矩阵C的某一列
    std::vector<std::vector<Vector3f>> C(n);
    for(int i = 0 ; i < n; i++) C[i].resize(n);
    std::vector<Vector3f> tmp(n);
    for (int i = 0; i < n; i ++ ) {
        for(int j = 0 ; j < n ; j++){
            tmp[j] = B[j][i];
        }
        BSplineCurve curve0(tmp, 3, true);
        for(int j = 0 ; j < n ; j++){
            C[j][i] = curve0.getControlPoint(j);
        }
    }
    for(int i = 0 ; i < n ; i++){
        for(int j = 0 ; j < n ; j++){
            controlPoints[i][j] = C[i][j];
        }
    }
	
}

BSplineSurface::BSplineSurface(int fitting) {
    //先从球面上取(n)×(n)个数据点（矩阵A）
    n = 10;
    int h = 3;
    controlPoints.resize(n);
    
    for (int i = 0; i < n; i ++ ) {
        for (int j = 0; j < n; j ++ ) {
            float alpha = i/((n-1)*1.f)*PI;
            float theta = j/((n-1)*1.f)*PI*2.f;

            float x = sin(alpha)*cos(theta);
            float y = sin(alpha)*sin(theta);
            float z = cos(alpha);
            //controlPoints[i].push_back(Vector3f(x,y,((float)(rand() % 1000) / 1000.f - 0.5f) * 0.2f));
            controlPoints[i].push_back(Vector3f(x,y,z));

        }
    }
    // 对每行的n+1个数据点进行插值，得到n个控制顶点，填入矩阵B中的某一行
	
    std::vector<std::vector<Vector3f>> B(n);
    for (int i = 0; i < n; i ++ ) {
        BSplineCurve curve0(controlPoints[i], 3, h);
        for(int j = 0 ; j < h+1 ; j++){
            B[i].push_back(curve0.getControlPoint(j));
        }
    }
	//int xx = 4;
	//float yy = B[xx, 0) + B(xx, 1) + B(xx, 2) + B(xx, 3) + B(xx, 4);
    // 对矩阵B的每一列的n个控制顶点进行插值，得到n个控制顶点，填入矩阵C的某一列
    std::vector<std::vector<Vector3f>> C(h+1);
    for(int i = 0 ; i < h+1; i++) C[i].resize(h+1);
    std::vector<Vector3f> tmp(n);
    for (int i = 0; i < h+1; i ++ ) {
        for(int j = 0 ; j < n ; j++){
            tmp[j] = B[j][i];
        }
        BSplineCurve curve0(tmp, 3, h);
        for(int j = 0 ; j < h+1 ; j++){
            C[j][i] = curve0.getControlPoint(j);
        }
    }
    for(int i = 0 ; i < h+1 ; i++){
        for(int j = 0 ; j < h+1 ; j++){
            controlPoints[i][j] = C[i][j];
        }
    }
	
}

// 返回曲面上一个点
Vector3f BSplineSurface::get(float u, float v) {
    // 按行遍历控制顶点，基于每行控制顶点生成一条曲线
    // 在曲线上的v处取一点存下来
    std::vector<Vector3f> vec;
    for (int i = 0; i < n; i ++ ) {
        BSplineCurve curve0(controlPoints[i], 3);
        vec.push_back(curve0.get(v));
    }
    // 利用刚得到的点生成一条纵向曲线，取曲线的u处
    BSplineCurve curve1(vec, 3);
    return curve1.get(u);
}