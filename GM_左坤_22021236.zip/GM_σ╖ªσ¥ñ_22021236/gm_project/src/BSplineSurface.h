#pragma once
#include "BSplineCurve.h"
#include <vector>
#include <Eigen/Dense>
using Eigen::Vector3f;

class BSplineSurface {
public:
    // 控制顶点写死在构造函数里面
    BSplineSurface();

    BSplineSurface(bool interpolation);

    BSplineSurface(int fitting);

    // 返回曲面上一个点
    Vector3f get(float u, float v);

private:
    std::vector<std::vector<Vector3f>> controlPoints;
    // n+1是控制顶点数量
    int n;
};