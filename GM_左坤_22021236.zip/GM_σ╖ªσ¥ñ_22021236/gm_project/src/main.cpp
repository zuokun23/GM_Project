#include "Tiny2DEngine.h"
#include "Triangle.h"
#include "BSplineSurface.h"
#include <vector>

// Derive a subclass from the engine
class MyApp : public Tiny2DEngine {
public:
    // Constructor
    MyApp(HINSTANCE hinst, int w, int h) : Tiny2DEngine(hinst, w, h) {}

    void onInit() override {
		
        //插值
        BSplineSurface surf(true);
        //拟合
        //BSplineSurface surf(0);
        for (float u = 0; u < 1; u += 0.02) {
            std::vector<Vector3f> tv;
            for (float v = 0; v < 1; v += 0.02) {
                tv.push_back(surf.get(u,v));
            }
            points.push_back(tv);
        }

        int m = points.size(), n = 0;
        if(m != 0)
            n = points[0].size();

        for(int i = 0 ; i < m-1 ; i++){
            for(int j = 0 ; j < n-1 ; j++){
                triangles.push_back(Triangle3D{points[i+1][j], points[i][j+1], points[i][j] });
                triangles.push_back(Triangle3D{points[i+1][j], points[i+1][j+1], points[i][j+1] });
            }
        }
    }

    void onMain() override {
        /*
        for (int i = 0; i < points.size(); i ++ ) {
            for (int j = 0; j < points[i].size(); j ++ ) {
                drawPoint(points[i][j], 5, Vector3f(1,0,0));
            }
        }*/
		
        for(int i = 0 ; i < triangles.size() ; i++){
            drawTriangle(triangles[i]);
        }
		/*
		std::vector<Vector3f> dp;
		dp.push_back(Vector3f(-0.75, 0, 0));
		dp.push_back(Vector3f(-0.5, 0.5, 0));
		dp.push_back(Vector3f(0, 0.5, 0));
		dp.push_back(Vector3f(0.5, 0.5, 0));
		dp.push_back(Vector3f(0.75, 0, 0));
		BSplineCurve curve(dp, 3, 4);
		for (float t = 0; t < 1; t += 0.01) {
			drawPoint(curve.get(t), 5, Vector3f(1, 0, 0));
		}
		for (const auto &p : dp)
			drawPoint(p, 5, Vector3f(0, 0, 1));
		*/
    }

private:
    std::vector<std::vector<Vector3f>>  points;
    std::vector<Triangle3D> triangles;
};

// Main function for Win32 Application
int WinMain(HINSTANCE hinstance,
			HINSTANCE hprevinstance,
			LPSTR lpcmdline,
			int ncmdshow) {
    MyApp app(hinstance, 600, 600);     // Create a window
    app.init();                         // Necessary initializations
    app.mainloop();                     // Enter the main loop where stuff gets shown and mouse/keyboard gets answered
}